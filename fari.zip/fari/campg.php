<?php 
 // camera object;
class cameras{
    public $image;
    public $name;
    public $price;
    }
    $c1=new cameras;
    $c1->image="c1.png";
    $c1->name="Canon";
    $c1->price="5000";
    $c2=new cameras;
    $c2->image="c2.png";
    $c2->name="Nikon";
    $c2->price="10,000";
    $c3=new cameras;
    $c3->image="c3.png";
    $c3->name="Polo";
    $c3->price="16,000";
    $c4=new cameras;
    $c4->image="c4.png";
    $c4->name="Canon HD";
    $c4->price="1,20000";
    $cameras=[$c1,$c2,$c3,$c4];
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </head>
    <body>
    <div class="container " >
    <div class="row">
    <?php 
    foreach($cameras as $cam){
        ?>
        <div class="col-3">
        <div class="card">
         
          <div class="card-body">
          <img class="card-img-top" src="images/<?php echo $cam->image ?>" alt="" >
          </div>
          <div class="card-footer">
            <p class="card-title pl-2"><?php echo $cam->name ?></p>
            <p class="card-text pl-2 text-danger"><?php echo $cam->price ?></p>
            </div>
        </div>
        </div>
        
        <?php
    }
    ?>
    </div>
    </div>
        
    </body>
    </html>