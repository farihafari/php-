<?php
/**
 * @author: Sohel Rana
 * @URL: http://sohelrana.me
 * @description: Function uverriding PHP.
 */

class ParentClass {
    public function sharing() {
        echo "sharing parent class";
    }
}

class ChildClass extends ParentClass {

    public function sharing() {
        echo "sharing child ";
    }
}

$obj1 = new ParentClass();
$obj2 = new ChildClass();

$obj1->sharing();
$obj2->sharing();
?>