<?php 
$color1=['red','blue','green'];
$color2=["yellow","black","orange"];
$merged= array_merge($color,$color2);
  {
       var_dump ($merged);
  
}


?>