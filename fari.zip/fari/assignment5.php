<?php 
class physics{
    public $method;
    public $formulae;
    public $solid_material;

   function implimentation (){
       echo "implimentation";
   }
   function observation (){
       echo "observation";
   }
   function experiment(){
       echo "experiment";
   }
   function invention(){
       echo "invention";
   }
   function variation (){
       echo "variation";
   }
}
$modern_physics= new physics;
$modern_physics-> experiment();
?>