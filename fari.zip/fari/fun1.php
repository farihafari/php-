
<?php
 include("my functions.php");
    h1();
    // echo add(3,2);
// printmyname();
// br();
// printmyname();
// br();
// printmyname();
// br();
?>