<?php 
class catagories {
    public $id;
    public $name;
}
$cat1= new catagories;
$cat1->id=1;
$cat1->name="cameras";
$cat2=new catagories;
$cat2->id=2;
$cat2->name="mobiles";
$cat3=new catagories;
$cat3->id=3;
$cat3->name="watches";
$catagories=[$cat1, $cat2, $cat3];
// camera object;
class cameras{
  public $image;
  public $name;
  public $price;
  }
  $c1=new cameras;
  $c1->image="c1.png";
  $c1->name="Canon";
  $c1->price="5000";
  $c2=new cameras;
  $c2->image="c2.png";
  $c2->name="Nikon";
  $c2->price="10,000";
  $c3=new cameras;
  $c3->image="c3.png";
  $c3->name="Polo";
  $c3->price="16,000";
  $c4=new cameras;
  $c4->image="c4.png";
  $c4->name="Canon HD";
  $c4->price="1,20000";
  $cameras=[$c1,$c2,$c3,$c4];
   // mobile object;
class mobiles{
  public $image;
  public $name;
  public $price;
  }
  $mob1=new mobiles;
  $mob1->image="Tecno1.png";
  $mob1->name="Sony Xperia";
  $mob1->price="20,000";
  $mob2=new mobiles;
  $mob2->image="Oppo1.png";
  $mob2->name="Oppo c2";
  $mob2->price="27,000";
  $mob3=new mobiles;
  $mob3->image="Infinix1.png";
  $mob3->name="iphone";
  $mob3->price="16,000";
  $mob4=new mobiles;
  $mob4->image="Vivo2.png";
  $mob4->name="vivo";
  $mob4->price="1,20000";
  $mobiles=[$mob1,$mob2,$mob3,$mob4];
  // watches object;
  class watch{
    public $image;
    public $name;
    public $price;
    }
    $w1=new watch;
    $w1->image="w1.png";
    $w1->name="Canon";
    $w1->price="5000";
    $w2=new watch;
    $w2->image="w2.png";
    $w2->name="Nikon";
    $w2->price="10,000";
    $w3=new watch;
    $w3->image="w3.png";
    $w3->name="Polo";
    $w3->price="16,000";
    $w4=new watch;
    $w4->image="w4.png";
    $w4->name="Canon HD";
    $w4->price="1,20000";
    $watches=[$w1, $w2, $w3, $w4];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container ">
<div class="row">
 <div class="col-4">
<h6>Catagories</h6>
  <ul class="nav">
  <?php 
  foreach($catagories as $items){
      ?>
       <li class="nav-item">
      <a class="nav-link" href="mobpage.php?cid=<?php echo $items->id?>"> <?php echo $items->name ?></a>
    </li>
      <?php 
  }
  ?>
  </ul>
  </div>
</div>
<div class="col-8 ">
    <div class="row">
    <?php 
    if (isset($_GET['cid'])){
    ?>


    <?php
    if($_GET['cid']==1){
      foreach($cameras as $cam){
        ?>
        <div class="col-3">
        <div class="card">
          <div class="card-body">
          <img class="card-img-top" src="images/<?php echo $cam->image ?>" alt="" >
          </div>
          <div class="card-footer">
            <!-- <p class="card-title pl-2"><?php echo $cam->name ?></p>
            <p class="card-text pl-2 text-danger"><?php echo $cam->price ?></p> -->
            </div>
        </div>
        </div>
     
    
    <?php
       
      }
    }
     elseif($_GET['cid']==2){
      foreach($mobiles as $mob){
        ?>
        <div class="col-3">
        <div class="card">
          <div class="card-body">
          <img class="card-img-top" src="images/<?php echo $mob->image ?>" alt="" >
        </div>

        <div class="card-footer">

            <!-- <p class="card-title pl-2"><?php echo $mob->name ?></p>
            <p class="card-text pl-2 text-danger"><?php echo $mob->price ?></p> -->
          </div>
        </div>
        </div>
    
    
    <?php
     
    }
  }
    else{
    foreach($watches as $watch){
    ?>
      <div class="col-3">
        <div class="card">
          <div class="card-body">
          <img class="card-img-top" src="images/<?php echo $watch->image ?>" alt="">
          </div>
            <div class="card-footer">
            <!-- <p class="card-title pl-2"><?php echo $watch->name ?></p>
            <p class="card-text pl-2 text-danger"><?php echo $watch->price ?></p> -->
          </div>
        </div>
        </div> 
      
  <?php
}
}
}
    ?>
   </div>  
   </div>
 </div>
</div>

</body>
</html>