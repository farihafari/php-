
    <?php 
    // mobile object;
class mobiles{
    public $image;
    public $name;
    public $price;
    }
    $mob1=new mobiles;
    $mob1->image="Tecno1.png";
    $mob1->name="Sony Xperia";
    $mob1->price="20,000";
    $mob2=new mobiles;
    $mob2->image="Oppo1.png";
    $mob2->name="Oppo c2";
    $mob2->price="27,000";
    $mob3=new mobiles;
    $mob3->image="Infinix1.png";
    $mob3->name="iphone";
    $mob3->price="16,000";
    $mob4=new mobiles;
    $mob4->image="Vivo2.png";
    $mob4->name="vivo";
    $mob4->price="1,20000";
    $mobiles=[$mob1,$mob2,$mob3,$mob4];
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </head>
    <body>
    <div class="container  " >
    <div class="row">
    <?php 
    foreach($mobiles as $mob){
        ?>
        <div class="col-3">
        <div class="card">
          <div class="card-body">
          <img class="card-img-top" src="images/<?php echo $mob->image ?>" alt="" >
        </div>

        <div class="card-footer">

            <p class="card-title pl-2"><?php echo $mob->name ?></p>
            <p class="card-text pl-2 text-danger"><?php echo $mob->price ?></p>
          </div>
        </div>
        </div>
     
        
        <?php
    }
    ?>
    </div>

       </div>
    </body>
    </html>