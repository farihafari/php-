<?php 
$Email="fariha@gmail.com";
$Pswrd="fariha123";
$email=$_POST['email'];
$pswrd=$_POST['pswrd'];
if($Email==$email && $Pswrd==$pswrd){
    echo" correctly login";
}
else{
    echo"sorry uncorrect";
}
?>