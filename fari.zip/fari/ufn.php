<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <style>
         img{
             height: 100px;
             width: 150px;
         }
     </style> 
    </head>
<body>
    <div class="container">
<form action="" method="post">
    <label for=""> Enter Your Number
    </label>
    <input type="number" name="number">
    <input type="submit" name="submit" value="submit">
</form>
<?php 

if(isset($_POST['submit'])){
    $num=$_POST['number'];
    $ucode1="0331";
    $ucode2="0332";
    $ucode3="0333";
    $ucode4="0334";
    $ucode5="0335";
    $ucode6="0336";
    $result=substr($num,0,4);
    // $comp=strcmp($ucode1,$ucode2,$ucode3,$ucode4,$ucode5,$ucode6,$result);
    $img="ufn.png";
    ?>
<?php

if($result==$ucode1 ||$result==$ucode2  ||$result==$ucode3 ||$result==$ucode4 ||$result==$ucode5 ||$result== $ucode6){
    ?>
    <img src="images/<?php echo $img ?>" alt="">
    <?php echo "Yes Your Number Is Ufone Network";?>

    <?php
}
else{
    echo "its not your ufone number";
}
    
}
?>

    </div>
</body>
</html>