<?php 
class book{
    public $pages;
    private $material;
    function read (){
        echo "reading by person";
    }
    function learn (){
        echo "learing";
    }
    function lead (){
        echo "leading to person ";
    }
}
$mybook = new book;
$mybook-> read ();
?>