<?php

/**
 * @author: Sohel Rana
 * @URL: http://sohelrana.me
 * @description: Function overloading in PHP.
 */
class SocialMedia
{

    public function __call($funName, $arguments)
    {

        $funArray = array('sharaMessage', 'sharaMessage2');
        if (in_array($funName, $funArray) === false) {
            die("Method does not exist");
        }

        if (count($arguments) === 2) {
            $this->sharaMessage2($arguments[0], $arguments[1]);
        } elseif (count($arguments) === 1) {
            $this->sharaMessage($arguments[0]);
        } else {
            echo "Unknown method";
            return false;
        }
    }

    public function sharaMessage($para)
    {

        echo "sharaMessage() with one parameter";

    }

    public function sharaMessage2($para1, $para2)
    {

        echo "sharaMessage() with two parameter";

    }

}

$object = new SocialMedia();
$object->sharaMessage('hello');
$object->sharaMessage2('hello', "hello2");
$object->sharaMessage3('hello');
?>