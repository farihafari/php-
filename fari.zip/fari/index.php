<?php
class car {
    public $name;
    public $color;
    function drive(){
        echo "car is being driven";
    }
    function accelerate(){
        echo "car is accelerating";
    }
    function breaks(){
        echo "break";
    }
} 
$mycar = new car;
$mycar->name="toyota corolla";
$yourcar = new car;
$yourcar-> drive();
?>