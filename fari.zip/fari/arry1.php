<?php
$fruits=["apple","bnana","mango"];
    foreach($fruits as $item){
        echo $item."<Br>";
    }
?>