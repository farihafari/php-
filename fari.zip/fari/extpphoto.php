<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
   <div class="container">
       <form action="" method="post">
           <label for="">Enter Your File Name</label> 
           <input type="text" name="txtfile">
           <input type="submit" name="submit" value="submit">
       </form>
       <?php 
       if (isset($_POST['submit'])){
           $txtfile=$_POST['txtfile'];
           $code=explode(".",$txtfile);
           $last=substr(strrchr($txtfile,'.'),1);
           $pcode1="jpg";
           $pcode2="svg";
           $pcode3="png";
           $pcode4="jpeg";
           if($last==$pcode1 || $last==$pcode2 || $last==$pcode3 || $last==$pcode4){
               echo $last;
           }
           else{
               echo "sorry only extension of images allow here";
           }
       }
       ?>
   </div> 
</body>
</html>