<?php
$number=$_POST["number"];
$times=$_POST["times"];
if($number%2!=0){
echo 
}
?>