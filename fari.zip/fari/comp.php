<?php 
$passwordsaved="123";
$passwordgiven="123";
$result=strcmp($passwordsaved, $passwordgiven);
if($result==0){
    echo "same he";
}
else
{
    echo"same nhi he";
}

?>