<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <form method="post" action="">
        <label for="">number</label>
        <input type="number" name="number">
        <label for="">times</label>
        <input type="number" name="num">
        <input type="submit" value="submit" name="submit">
        </form>
        <?php 
        if(isset($_POST['submit'])){
            $number=$_POST['number'];
            $num=$_POST['num'];
        
        ?>
        <table class="table">
        <tbody>
        <?php
        for($i=1; $i<=$num; $i++){
        ?>
        <?php 
        $a=$i*$number;
        if($i%2!=0){
            echo" <tr style='background-color:black; color:white;'>
            <td scop=row>$number</td>
            <td>x</td>
            <td>$i</td>
            <td>=</td>
            <td>$a</td>
            </tr>";
        } else{
            echo" <tr>
            <td>$number</td>
            <td>x</td>
            <td>$i</td>
            <td>=</td>
            <td>$a</td>
            </tr>";
        }
    }
}

        ?>
       
        </tbody>
        </table>
    </div>
</body>
</html>