<?php
$fruits=["apple"=>"red","mango"=>"green","banana"=>"yellow"];
 foreach($fruits as $key => $value) {
     echo $key." ".$value." "."hota he <br>";
 }


?>