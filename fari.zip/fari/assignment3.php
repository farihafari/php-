<?php 
class bycycle{
    
    public $wheel;
    public $handle;
    public $paddle;
    public $bycycle_chain;
    public $harron;
    public $break;
    function run(){
        echo "running..";
    }
    function ride() {
        echo "riding";
    }
    function fitness() {
        echo "exserising";
    }
    function climb() {
  echo "climbing";
    }
    function conversion() {
        echo "conversion of energies";
    }
    
}
$mybycycle = new bycycle;
    $mybycycle->conversion();
?>