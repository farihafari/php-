<?php 
interface IShap{
    function draw();
}
class rectangle implements IShap{
    function draw()
    {
        echo "rectangle is drawn";
    }

}
$s=new rectangle;
$s->draw();
?>