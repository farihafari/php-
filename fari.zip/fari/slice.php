
  <?php
echo '<h1>slice into 3 parts </h1><br>';
$input_arry=['1','2','3','4','5','6','7','8','9','10','11'];
print_r(array_chunk($input_arry,5,true));
?>
