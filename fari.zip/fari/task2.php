<?php 
class student{
    public $id;
    public $name;
    public $email;
    private $password;
}
$student1= new student;
$student1-> id= 1;
$student1-> name="basit";
$student1->email=$student1->name."@gmail.com";
$student2= new student;
$student2-> id= 2;
$student2-> name="faiz";
$student2->email=$student2->name."@gmail.com";
 $student=[$student1,$student2];
?>
<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
 
       <table class="table">
       <thead class="thead-light">
     
           <tr>
               <th>id</th>
               <th>name</th>
               <th>Email</th>
           </tr>
       </thead>
       <tbody>
       <?php 
       $i=0;
  while($i< count($student))
  {
      $items=$student[$i];
      ?>
           <tr>
               <td scope="row"><?php echo $items->id;?></td>
               <td><?php echo $items->name;?></td>
               <td><?php echo $items->email;?></td>
           </tr>
           <?php
           $i++;
  }
  ?>
       </tbody>
   </table>
  
      
  
  </body>
</html>