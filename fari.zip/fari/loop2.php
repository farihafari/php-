<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>table 2</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <table class="table table-striped">
        <thead>
            <tr>
                <th class="text-right">table of 2</th>
                
            </tr>
        </thead>
        <tbody>
            <?php 
            for($i=0; $i<10 ; $i++){
               $n=$i+1
                ?>
    
                <tr>
                <td scope="row">2</td>
                <td>x</td>
                <td><?php echo $n ; ?></td>
                <td>=</td>
                <td><?php echo $n*2?></td>
            </tr>
            <?php
            }
           ?>
        </tbody>
    </table>
</body>
</html>