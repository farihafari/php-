<?php 
$nam="home.jpg";
$arr=explode (".",$nam);
echo $arr[1];
?>