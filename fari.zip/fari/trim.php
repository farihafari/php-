<?php 

$nam="a very g ood";
echo trim($nam);

?>