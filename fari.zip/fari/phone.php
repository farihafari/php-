<?php 
class telephone{
    public $buttons;
    public $wire;
    public $receiver;
function dail(){
    echo "dailing..";
}
function receive(){
    echo "receiving..";
}
function call(){
    echo "calling";
}
function ring(){
 echo "ringing";
}
function redail(){
    echo "redailing";
}

}
$phone = new telephone;
$phone->dail();
?>