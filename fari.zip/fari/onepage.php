<?php 
class catagories{
    public $id;
    public $name;
}
$cat1= new catagories;
$cat1->id=1;
$cat1->name="cameras";
$cat2=new catagories;
$cat2->id=2;
$cat2->name="mobiles";
$cat3=new catagories;
$cat3->id=3;
$cat3->name="watches";
$catagories=[$cat1, $cat2, $cat3];
// camera object;
class cameras{
    public $image;
    public $name;
    public $price;
    }
    $c1=new cameras;
    $c1->image="cam1.png";
    $c1->name="Canon DSLR Digital Camera";
    $c1->price="590,999";
    $c2=new cameras;
    $c2->image="cam2.png";
    $c2->name="Sony Alpha Digital Camera";
    $c2->price="116,490";
    $c3=new cameras;
    $c3->image="cam3.png";
    $c3->name="Panasonic Lumix HD Camera";
    $c3->price="440,999";
    $c4=new cameras;
    $c4->image="cam4.png";
    $c4->name="Nikon D7099 HD Camera";
    $c4->price="145,999";
    $c5=new cameras;
    $c5->image="cam5.png";
    $c5->name="Nikon D5600 HD Camera";
    $c5->price="118,499";
    $c6=new cameras;
    $c6->image="cam6.png";
    $c6->name="Canon EOS DSLR Camera";
    $c6->price="358,999";
    $c7=new cameras;
    $c7->image="cam7.png";
    $c7->name="Canon 705D DSLR Camera";
    $c7->price="80,999";
    $c8=new cameras;
    $c8->image="cam8.png";
    $c8->name="Sony A7R3 Digital HD Camera";
    $c8->price="330,999";
    
    $cameras=[$c1,$c2,$c3,$c4,$c5,$c6,$c7,$c8];
     // mobile object;
class mobiles{
    public $image;
    public $name;
    public $price;
    }
    $mob1=new mobiles;
    $mob1->image="Tecno1.png";
    $mob1->name="Techno Spark plus";
    $mob1->price="20,000";
    $mob2=new mobiles;
    $mob2->image="Oppo1.png";
    $mob2->name="Oppo c2";
    $mob2->price="57,000";
    $mob3=new mobiles;
    $mob3->image="Infinix1.png";
    $mob3->name="Infinix Hot 8";
    $mob3->price="23,000";
    $mob4=new mobiles;
    $mob4->image="Vivo2.png";
    $mob4->name="vivo";
    $mob4->price="1,20000";
    $mob5=new mobiles;
    $mob5->image="realme1.png";
    $mob5->name="Realme 7 Pro";
    $mob5->price="54,999";
    $mob6=new mobiles;
    $mob6->image="sumsung.png";
    $mob6->name="SUMSUNG Z Flod";
    $mob6->price="3,39000";
    $mob7=new mobiles;
    $mob7->image="itel.png";
    $mob7->name="Itel A48";
    $mob7->price="11,699";
    $mob8=new mobiles;
    $mob8->image="Xiaomi.png";
    $mob8->name="Xiaomi Poco M3";
    $mob8->price="24,999";

    $mobiles=[$mob1,$mob2,$mob3,$mob4,$mob5,$mob6,$mob7,$mob8];
    // watches object;
  class watch{
    public $image;
    public $name;
    public $price;
    }
    $w1=new watch;
    $w1->image="w5.png";
    $w1->name="Omega watch";
    $w1->price="50,000";
    $w2=new watch;
    $w2->image="w6.png";
    $w2->name="Longines.";
    $w2->price="15,000";
    $w3=new watch;
    $w3->image="w7.png";
    $w3->name="Rado";
    $w3->price="12,000";
    $w4=new watch;
    $w4->image="w8.png";
    $w4->name="Raymond Weil";
    $w4->price="18,000";
    $w5=new watch;
    $w5->image="w9.png";
    $w5->name="Rolex";
    $w5->price="100,000";
    $w6=new watch;
    $w6->image="w10.png";
    $w6->name="Rolex silver";
    $w6->price="80,000";
    $w7=new watch;
    $w7->image="w11.png";
    $w7->name="Tag Heuer";
    $w7->price="70,000";
    $w8=new watch;
    $w8->image="w12.png";
    $w8->name="Citizen";
    $w8->price="80,000";
    $watches=[$w1, $w2, $w3, $w4,$w5,$w6,$w7,$w8];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<style>
    .container{
        height:  auto;
        /* background-color: pink; */
    }
    .img1{
        height: 100px;
        width: 100px;
    }
    .col1{
        border-right-style:1px solid;
        border-color:grey; 
    }
</style>
</head>
<body>
    <div class="container">
    <div class="row mt-2">
    <img src="images/logo_files/4293759380_a7714f79-0ccf-4964-a650-1ff67a8ea17c.png" style="height:50px; width:60px;" alt="">
    </div>
    <div class="row ">
        <div class="col-3 mt-2 col1">
        <h6>Catagories</h6>
        <ul class="nav flex-column">
        <?php 
        foreach($catagories as $items){
            ?>
            <li class="nav-item">
      <a class="nav-link" href="onepage.php?cid=<?php echo $items->id?>"><?php echo $items->name ?></a>
    </li>
    <?php
        }
        ?>
  </ul>
        </div>
        <div class="col-9">
         <div class="row bg-white">
         <?php 
         if(isset($_GET['cid'])){
             ?>
          <?php 
          if($_GET['cid']==1){
              foreach($cameras as $cam){
            ?>
             <div class="col-3 mt-3 ">
                 <div class="card">
                     <div class="card-body text-center">
                         <img src="images/<?php echo $cam->image ?>" class="img-fluid img1" alt="">
                     </div>
                     <div>
                         <p class="card-title font-weight-bold pl-2"><?php echo $cam->name ?></p>
                         <p class="card-text text-danger pl-2">Rs:<?php echo $cam->price ?></p>
                     </div>
                     </div>
                 </div>
            <?php
              }
          }
          elseif($_GET['cid']==2){
              foreach($mobiles as $mob){
                  ?>
                  <div class="col-3 mt-3">
                 <div class="card">
                     <div class="card-body text-center">
                         <img src="images/<?php echo $mob->image ?>" alt="">
                     </div>
                     <div>
                         <p class="card-title font-weight-bold pl-2"><?php echo $mob->name ?></p>
                         <p class="card-text text-danger pl-2">Rs:<?php echo $mob->price ?></p>
                     </div>
                     </div>
                 </div>
                  <?php
              }
          }
          else{
              foreach ($watches as $watch){
                  ?>
                  <div class="col-3 mt-3 ">
                 <div class="card">
                     <div class="card-body text-center">
                         <img src="images/<?php echo $watch->image ?>" class="img-fluid img2"  alt="">
                     </div>
                     <div>
                         <p class="card-title font-weight-bold pl-2"><?php echo $watch->name ?></p>
                         <p class="card-text text-danger pl-2">Rs:<?php echo $watch->price ?></p>
                     </div>
                     </div>
                 </div>
                  <?php
              }
          }
        }
          ?>
             </div>
         </div>
          </div>
        </div>
</body>
</html>
