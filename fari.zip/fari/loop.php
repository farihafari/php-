
<?php

for($i=0; $i<10; $i++){
echo "Number is $i <br>";
}
$p=67;
$number= $p >60 ? "you are pass":"fail";
echo $number;



$num=256;


if($num%2==0){
    echo "<br> your number is even";
}
else{
    echo " <br> your number is odd";
}

?>