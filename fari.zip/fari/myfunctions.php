<?php

function printmyname(){

echo "fariha";
}
function br(){
    
    echo "<br>";
    }
    function add($a,$b){
        return$a+$b;
    }
    function h1(string $text="usman nasir"){
        echo "<h1>$text</h1>";
    }
    ?>