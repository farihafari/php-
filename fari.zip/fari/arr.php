<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <ul>
    <?php
$fruit_color=['apple'=>['red','120kg'],'mango'=>['green','120kg'],'banana'=>['yellow','120kg']];

?>
<?php
foreach($fruit_color as $key => $value){
 ?>
 
 <li><?php echo $key.''.$value.''.hota he <br>.''.os ka rate'. $  ?></li> 
 <?php 
}
?>
    </ul>
</body>
</html>