<?php 
$str="Pakistan Zindabad";
$pak= substr($str ,0,3);
echo $pak;

?>