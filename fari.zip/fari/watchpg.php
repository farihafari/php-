<?php 
  // watches object;
  class watch{
    public $image;
    public $name;
    public $price;
    }
    $w1=new watch;
    $w1->image="watch1.png";
    $w1->name="Canon";
    $w1->price="5000";
    $w2=new watch;
    $w2->image="dwatch2.png";
    $w2->name="Nikon";
    $w2->price="10,000";
    $w3=new watch;
    $w3->image="goldwatch3.png";
    $w3->name="Polo";
    $w3->price="16,000";
    $w4=new watch;
    $w4->image="rolexwatche4.png";
    $w4->name="Canon HD";
    $w4->price="1,20000";
    $watches=[$w1, $w2, $w3, $w4];

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </head>
    <body>
    <div class="container ">
    <div class="row">
    <?php 
    foreach($watches as $watch){
        ?>
      <div class="col-3">
        <div class="card">
          <div class="card-body">
          <img class="card-img-top" src="images/<?php echo $watch->image ?>" alt="">
          </div>
            <div class="card-footer">
            <p class="card-title pl-2"><?php echo $watch->name ?></p>
            <p class="card-text pl-2 text-danger"><?php echo $watch->price ?></p>
          </div>
        </div>
        </div>
        <?php
    }
    ?>
    </div>
        </div>
    </body>
    </html>