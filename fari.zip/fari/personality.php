<?php 
class sir_mazhar_karimi{
    public $education;
    private $features;
    private $hobbies;
    
function teach(){
echo "teaching";
}
function motivate(){
    echo "motivating";
}
function eat (){
    echo "eating";
}
function listen(){
    echo "listening";
}
function talk(){
    echo "talking";
}
function walk(){
    echo "walking";
} 
function proportionality (){
    echo "proportional to us";
} 
function think(){
    echo "thinking";
}
}
?>