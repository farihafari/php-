<?php 

abstract class tag
{
 
    public $_tagname;
   public function __construct(string $tagname)
    {
        $this->_tagname = $tagname;
    }
    function write($text)
    {
        echo "<$this->_tagname>$text</$this->_tagname>";
    }
}
class h1 extends tag{
    function __construct()
    {
        parent::__construct("h1");
    }
} 
$h=new h1();
$h->write("mazhar karimi");
?>