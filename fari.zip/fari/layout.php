<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<style>
    .container{
        height:  auto;
        background-color: pink;
    }
</style>
</head>
<body>
    <div class="container">
    <div class="row bg-secondry">
        <div class="col-3 bg-warning">
        <h6>Catagories</h6>
        <ul class="nav flex-column">
    <li class="nav-item">
      <a class="nav-link" href="">Link</a>
    </li>
    
  </ul>
        </div>
        <div class="col-9 bg-danger">
         <div class="row bg-white">
             <div class="col-3 d-flex ">
                 <div class="card">
                     <div class="card-body">
                         <img src="" alt="">
                     </div>
                     <div>
                         <h5 class="card-title">Title</h5>
                         <p class="card-text">Content</p>
                     </div>
                     </div>
                     <div class="card">
                     <div class="card-body">
                         <img src="" alt="">
                     </div>
                     <div>
                         <h5 class="card-title">Title</h5>
                         <p class="card-text">Content</p>
                     </div>
                     </div>
                     <div class="card">
                     <div class="card-body">
                         <img src="" alt="">
                     </div>
                     <div>
                         <h5 class="card-title">Title</h5>
                         <p class="card-text">Content</p>
                     </div>
                     </div>
                 </div>
             </div>
         </div>
          </div>
        </div>
    </div>
    </div>
</body>
</html>