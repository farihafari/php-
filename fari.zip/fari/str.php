<?php
$name="پاکستان";
echo strlen($name);


?>